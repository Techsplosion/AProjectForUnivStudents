users = {
    "ahmet": "İstinye123",
    "meryem": "4444",
    "kıvanç": "abc123",
    "meloşşş": "m58"
}
actions = {
    1: "Ürün ara",
    2: "Sepete git",
    3: "Satın al",
    4: "Oturum kapat",
    5: "Stoğu göster",
    6: "Çıkıs yap",
}
cart_actions = {
    1: "Ürün miktarını değiştir",
    2: "Ürün sil",
    3: "Sepeti boşalt",
    4: "Satın al"
}
products = {
    "ÜS": "üzüm suyu, 16$, 21",
    "PS": "portakal suyu, 4$, 32",
    "ES": "elma suyu, 8$, 33",
    "KS": "karışık meyve suyu, 19$, 1",
    "Y": "yumurta, 4$, 44",
    "E": "elma, 15$, 25",
    "MU": "muz, 18$, 19",
    "PO": "portakal, 12$, 27",
    "Ü": "üzüm, 14$, 35",
    "PA": "patates, 9$, 48",
    "ME": "meyve, 5$, 23",
    "KK": "kuşkonmaz, 3$, 6",
    "B": "brokoli, 7$, 20",
    "H": "havuç, 5$, 15",
    "D": "dondurma, 4$, 0",
    "BÇ": "balık çubuğu, 10$, 27",
    "T": "tavuk, 20$, 9",
}
